__version__ = "0.2.1"

__doc__ = """
Reference from Jianlin Su.
See https://github.com/bojone/bert4keras.
Version {}.
Change some codes.
""".format(__version__)