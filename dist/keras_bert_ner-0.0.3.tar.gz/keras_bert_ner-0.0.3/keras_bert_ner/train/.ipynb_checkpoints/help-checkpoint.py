from train_helper import get_train_args_parser

if __name__ == "__main__":
    parser = get_train_args_parser()
    parser.parse_args()
